<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header"><?php echo e(Auth::user()->name); ?>'s profile</div>
            <div class="card-body ml-5">
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="modal fade" id="pwd-change" tabindex="-1" role="dialog" aria-labelledby="Change password" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <?php echo Form::open(['route' => ['changePassword', Auth::id()]]); ?>

                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Change password</h5>
                                <div class="pull-right">
                                    <a @click="print" href="#" class="mt-auto mb-auto"><span aria-hidden="true" class="fa fa-lg fa-print"></span></a>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                            <div class="modal-body align-self-center text-center">
                                    <div class="form-group">
                                        <?php echo Form::label('current', 'Current password: '); ?>

                                        <?php echo Form::password('current', ['class' => 'form-control', 'required']); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo Form::label('new', 'New password: '); ?>

                                        <?php echo Form::password('new', ['class' => 'form-control', 'required']); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo Form::label('new2', 'Repeat new password: '); ?>

                                        <?php echo Form::password('new2', ['class' => 'form-control', 'required']); ?>

                                    </div>
                            </div>
                            <div class="modal-footer">
                                <?php echo Form::submit('Change', ['class' => 'btn btn-primary']); ?>

                                <?php echo Form::close(); ?>

                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <p><b>Nickname: </b> <?php echo e(Auth::user()->name); ?></p>
                        <p><b>Added GPX: </b> <?php echo e($gpx); ?></p>
                        <p><b>Added lyrics: </b> <?php echo e($lyrics); ?></p>
                    </div>
                    <div class="col-4 pull-right">
                        <div class="btn-group" role="group" aria-label="Profile actions">
                            <button class="btn btn-md btn-primary" data-toggle="modal" data-target="#pwd-change">Change password</button>
                            <button class="btn btn-md btn-primary">Change avatar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>