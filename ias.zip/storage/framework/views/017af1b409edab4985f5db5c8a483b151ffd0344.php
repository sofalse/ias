<?php $__env->startSection('styles'); ?>
    <?php echo editor_css(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" id="edit-form">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php echo Form::model($lyric, ['method' => 'put', 'route' => ['lyric.update', $lyric->id]]); ?>

        <div class="form-group">
            <?php echo Form::label('title', 'Title:'); ?>

            <?php echo Form::text('title', $lyric->title,['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('htmlc', 'Text:'); ?>

            <div id="editor">
                <textarea class="md" name="md"><?php echo e($lyric->md_text); ?></textarea>
                <!-- html textarea 需要开启配置项 saveHTMLToTextarea == true -->
                <textarea class="htmlc" name="htmlc"></textarea>
            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('gpx', 'Attach GPX:'); ?>

            <?php echo Form::select('gpx', $gpx, $lyric->gpx != null ? $lyric->gpx->id : null, ['placeholder' => 'Nothing', 'class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::submit('Submit changes', ['class' => 'btn btn-primary mr-auto']); ?>

            <button type="button" @click="show" class="btn btn-danger mr-auto">Delete Lyrics</button>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <?php echo editor_js(); ?>

    <?php echo editor_config(['id' => 'editor']); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>