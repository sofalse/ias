<?php $__env->startSection('styles'); ?>
    <?php echo editor_css(); ?>

    <link href="<?php echo e(asset('css/gpx.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a id="gpxAddBtn" href="<?php echo e(route('lyric.create')); ?>" class="btn btn-lg btn-primary">Add new lyrics</a>
    <div class="card">
        <table id="gpxTable" class="table table-bordered table-hover not-printable">
            <thead class="not-printable">
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Added on</th>
            <th>Updated on</th>
            <th>Linked GPX</th>
            <th>Text</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $lyrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lyric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="text-<?php echo e($lyric->id); ?>" tabindex="-1" role="dialog" aria-labelledby="Change password" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e($lyric->title); ?></h5>
                                <div class="pull-right">
                                    <a @click="print" href="#" class="mt-auto mb-auto"><span aria-hidden="true" class="fa fa-lg fa-print"></span></a>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                            <div class="modal-body align-self-center text-center printable">
                                <?php echo $lyric -> text; ?>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                <tr class="not-printable">
                    <td><?php echo e($lyric->id); ?></td>
                    <td><?php echo e($lyric->title); ?></td>
                    <td><?php echo e($lyric->user->name); ?></td>
                    <td><?php echo e($lyric->created_at); ?></td>
                    <td><?php echo e($lyric->updated_at); ?></td>
                    <?php if($lyric->gpx != null): ?>
                        <td><a href="<?php echo e('files/gpx/'.$lyric->gpx->filePath); ?>"><?php echo e($lyric->gpx->name); ?></a></td>
                    <?php else: ?>
                        <td><i>No GPXes found. <a href="<?php echo e(route('gpx.create')); ?>">Add one!</a></i></td>
                    <?php endif; ?>
                    <td><a href="#text-<?php echo e($lyric->id); ?>" data-toggle="modal" data-target="#text-<?php echo e($lyric->id); ?>">Show</a> | <a href=" <?php echo e(route('lyric.edit', ['id' => $lyric->id])); ?>">Edit</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="align-self-center not-printable">
            <?php echo e($lyrics->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>