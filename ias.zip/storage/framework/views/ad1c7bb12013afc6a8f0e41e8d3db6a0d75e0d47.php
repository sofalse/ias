<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/gpx.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a id="gpxAddBtn" href="<?php echo e(route('gpx.create')); ?>" class="btn btn-lg btn-primary">Add new GPX</a>
    <div class="card">
        <table id="gpxTable" class="table table-bordered table-hover">
            <thead>
                <th>ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Version</th>
                <th>Added on</th>
                <th>Updated on</th>
                <th>Lyrics</th>
                <th>Download</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $gpxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gpx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($gpx->id); ?></td>
                    <td><?php echo e($gpx->name); ?></td>
                    <td><?php echo e($gpx->user->name); ?></td>
                    <td><?php echo e($gpx->version); ?></td>
                    <td><?php echo e($gpx->created_at); ?></td>
                    <td><?php echo e($gpx->updated_at); ?></td>
                    <?php if($gpx->lyric != null): ?>
                        <td><?php echo e($gpx->lyric->title); ?></td>
                    <?php else: ?>
                        <td><i>No lyrics found. <a href="<?php echo e(route('lyric.create')); ?>">Add one!</a></i></td>
                    <?php endif; ?>
                    <td><a href="<?php echo e('files/gpx/'.$gpx->filePath); ?>">Download</a> | <a href="<?php echo e(route('gpx.edit', ['id' => $gpx->id])); ?>">Update</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="align-self-center">
            <?php echo e($gpxes->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>