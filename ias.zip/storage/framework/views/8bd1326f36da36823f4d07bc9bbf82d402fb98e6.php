<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <h1>Add new GPX</h1>
        <?php echo Form::open(['route' => 'gpx.store', 'files' => 'true']); ?>

            <div class="form-group">
                <?php echo Form::label('name', 'Title:'); ?>

                <?php echo Form::text('name', '', ['class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('gpx_file', 'GPX File:'); ?>

                <?php echo Form::file('gpx_file'); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('lyrics', 'Attach lyrics:'); ?>

                <?php echo Form::select('lyrics', $lyrics, null, ['placeholder' => 'Nothing', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('Submit', ['class' => 'btn btn-primary']); ?>

            </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>